﻿
namespace $safeprojectname$
{
    public class Model
    {
        public string Name { get; set; }

        public string Folder { get; set; }
    }
}
