﻿using System;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public interface IService
    {
        List<Model> DataItems { get; }
    }
}
